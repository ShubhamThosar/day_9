package Register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Connect.JDBCcon;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		Random rand = new Random();
		int  eid = rand.nextInt(9999) + 1000;
		String name=request.getParameter("name");
		String gender=request.getParameter("gender");
		String dob=request.getParameter("dob");
		String blood_group=request.getParameter("blood_group");

		String qualification=request.getParameter("qualification");
		String skill=request.getParameter("skill");
		String email=request.getParameter("email");
		String mobile=(request.getParameter("mobile"));
		String doj=request.getParameter("doj");
		String password=request.getParameter("password");
		String department=request.getParameter("department");
		
		String address=request.getParameter("address");
	
		
		
		
	

	
		

		/*EMP_id number(5) NOT NULL UNIQUE,
		Emp_name varchar2(30) NOT NULL,
		Gender char(1) NOT NULL,
		DOB date NOT NULL,
		Blood_group varchar2(4) NOT NULL,
		Qualification varchar2(10) NOT NULL,
		Skill varchar2(200) NOT NULL,
		Email varchar2(60) NOT NULL UNIQUE,
		Mobile long NOT NULL,
		DOJ date NOT NULL,
		password varchar2(20) NOT NULL UNIQUE,
		Department varchar2(30) NOT NULL,
		PRIMARY KEY (EMP_id)
		*/
		
		
		JDBCcon conn=new JDBCcon();
		Connection got=conn.getConnect();
		PrintWriter pw=response.getWriter();
		System.out.println("Connection zala");
		try {
			PreparedStatement pst=got.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setInt(1, eid);
			pst.setString(2, name);
			pst.setString(3, gender);
			pst.setString(4, dob);
			pst.setString(5, blood_group);
			pst.setString(6, qualification);
			pst.setString(7, skill);
			pst.setString(8, email);
			pst.setString(9, mobile);
			pst.setString(10, doj);
			pst.setString(11, password);
			pst.setString(12, department);
			pst.setString(13, address);
			pst.setString(14, "NAcc");
			int abc=pst.executeUpdate();
			System.out.println("Entered in database");
			
			HttpSession session=request.getSession();
			session.setAttribute("uname", name);
			pst.close();
			got.close();
			
			response.sendRedirect("RegSuccess.jsp");
			
			

			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
