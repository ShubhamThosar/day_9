
/* Drop Tables */

DROP TABLE Alloted_employee CASCADE CONSTRAINTS;
DROP TABLE HR CASCADE CONSTRAINTS;
DROP TABLE BU CASCADE CONSTRAINTS;
DROP TABLE Common_Employee CASCADE CONSTRAINTS;
DROP TABLE Employee CASCADE CONSTRAINTS;
DROP TABLE Systems CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE Alloted_employee
(
	Emp_name varchar2(30) NOT NULL,
	DOJ varchar2(20) NOT NULL,
	EMP_id number(5) NOT NULL ,
	BU_id varchar2(10) NOT NULL,
	system_id varchar2(20)  
);


CREATE TABLE BU
(
	BU_id varchar2(10) NOT NULL UNIQUE,
	BU_name varchar2(50) NOT NULL,
	BU_tools varchar2(100) NOT NULL,
	PRIMARY KEY (BU_id)
);


CREATE TABLE Common_Employee
(
	EMP_id number(5) NOT NULL UNIQUE
);


CREATE TABLE Employee
(
	EMP_id number(5) NOT NULL UNIQUE,
	Emp_name varchar2(30) NOT NULL,
	Gender char(1) NOT NULL,
	DOB date NOT NULL,
	Blood_group varchar2(4) NOT NULL,
	Qualification varchar2(10) NOT NULL,
	Skill varchar2(200) NOT NULL,
	Email varchar2(60) NOT NULL UNIQUE,
	Mobile varchar2(12) NOT NULL UNIQUE,
	DOJ date NOT NULL,
	password varchar2(20) NOT NULL ,
	Department varchar2(30) NOT NULL,
	
);


CREATE TABLE HR
(
	HR_name varchar2(30) NOT NULL,
	password varchar2(50),
	EMP_id number(5) NOT NULL UNIQUE,
	BU_id varchar2(10) NOT NULL UNIQUE
);


CREATE TABLE Systems
(
	system_id number ,
	status char(3),
	PRIMARY KEY (system_id)
);



/* Create Foreign Keys */

ALTER TABLE Alloted_employee
	ADD FOREIGN KEY (BU_id)
	REFERENCES BU (BU_id)
;


ALTER TABLE HR
	ADD FOREIGN KEY (BU_id)
	REFERENCES BU (BU_id)
;


ALTER TABLE Common_Employee
	ADD FOREIGN KEY (EMP_id)
	REFERENCES Employee (EMP_id)
;


ALTER TABLE HR
	ADD FOREIGN KEY (EMP_id)
	REFERENCES Employee (EMP_id)
;


ALTER TABLE Alloted_employee
	ADD FOREIGN KEY (EMP_id)
	REFERENCES Employee (EMP_id)
;


ALTER TABLE Alloted_employee
	ADD FOREIGN KEY (system_id)
	REFERENCES Systems (system_id)
;



